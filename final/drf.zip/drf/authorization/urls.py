from django.urls import path
from .views import login_view, UserViewSet

urlpatterns = [
    path('login/', login_view, name='login'),
    path('logout/', UserViewSet.as_view({'post': 'logout'}), name='logout'),
    path('check/', UserViewSet.as_view({'get': 'check'}), name='check'),
    path('register/', UserViewSet.as_view({'post': 'register'}), name='register'),
]
